<html class="js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" lang="en"  >

<!--<![endif]-->
<head>
<meta name="msvalidate.01" content="2D0C2D49381BF72093F8E664CFF3C49A">
<link rel="shortcut icon" href="http://static.mercadoshops.com/static/images/favicon.ico">
<!-- for mobile 2012-->
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- end mobile -->
<!-- env prod -->
<title>:: TEMPLATE I ::</title>

<link href="../css/themes/base.css" rel="stylesheet" type="text/css">
<link href="../css/jquery-ui-1.7.2.custom.css" rel="stylesheet" type="text/css">
<link href="../css/common/payment.css" rel="stylesheet" type="text/css">
<link href="../css/themes/chico-0.10.7.css" rel="stylesheet" type="text/css">
<link href="../css/themes/mesh-0.9.3.css" rel="stylesheet" type="text/css">
<link media="screen" href="../css/themes/fluid/basic.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/themes/fluid/basic.css">
<link rel="stylesheet" type="text/css" media="only screen and (min-width:640px) and (max-width:1024px)" href="../css/themes/fluid/tablet.css">
<link rel="stylesheet" type="text/css" media="only screen and (min-width:1024px)" href="../css/themes/fluid/desktop.css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/themes/fluid/componentes.css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/////personalized.css">
<style type="text/css">
body,td,th {
	font-family: ralewayregular;
}
body {
	background-color: #FFF;
}
</style>
<meta http-equiv="Content-Type: application/xhtml+xml; charset=UTF-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>

<body>
<?php include 'header.html'; ?>
<?php include 'home.html'; ?>
<?php include 'footer.html'; ?>
</body>
</html>
